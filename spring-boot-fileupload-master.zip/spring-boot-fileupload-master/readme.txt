#java -jar  spring-boot-fileupload-0.0.1-SNAPSHOT.jar -Dserver.port=8081 -Dserver.servlet.context-path=/fileuploadApp -Dapp.base.dir=/app

java -jar  spring-boot-fileupload-0.0.1-SNAPSHOT.jar -Dspring.config.location=C:\app\external_config\spring-boot-fileupload\config/application.properties